import pandas as pd

csv_path = 'UsersSample.csv'
df = pd.read_csv(csv_path)
print(df.head())

xlsx_path = 'UsersSample.xlsx'
df = pd.read_excel(xlsx_path)
print(df.head())

data = [['Alex',10],['Bob',12],['Clarke',13]]
df = pd.DataFrame(data,columns=['Name','Age'])
print(df['Name'])
print(df.iloc[0,0])
print(df.iloc[0:2,0:2])

df['Gen']=pd.DataFrame(['male','male','male'])
print(df.head())

df['one']=pd.DataFrame([1, 2, 3])
df['two']=pd.DataFrame([1, 2, 3, 4])
df['three']=pd.DataFrame([10,20,30])
df['four']=df['one']+df['three']
print(df)


del df['three']
print (df)

print (df.pop('three'))


df = pd.DataFrame([[1, 2], [3, 4]], columns = ['a','b'])
df2 = pd.DataFrame([[5, 6], [7, 8]], columns = ['a','b'])

df = df.append(df2)
print (df)

df = df.drop(0)
print (df)

d = {'one' : [1, 2, 3], 'two' : [10, 20, 30]}
df = pd.DataFrame(d, index=['a', 'b', 'c'])
print (df)
