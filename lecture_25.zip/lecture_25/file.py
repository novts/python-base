import threading
import time

def search(n):
    for var in list(range(n)):
        fhand = open('mbox.txt')
        count = 0
        for line in fhand:
            if line.startswith('From:'):
                line
    fhand.close()

start = time.time()

search(10)
search(10)

print("Execution time = {0:.5f}".format(time.time() - start))

start = time.time()

# creating thread 
t1 = threading.Thread(target=search, args=(10,)) 
t2 = threading.Thread(target=search, args=(10,)) 
  
# starting thread 1 
t1.start() 
# starting thread 2 
t2.start() 
  
# wait until thread 1 is completely executed 
t1.join() 
# wait until thread 2 is completely executed 
t2.join() 
  
# both threads completely executed 
print("Execution time = {0:.5f}".format(time.time() - start))
