import threading, sys

def printer():
    print('threading print')

def fn():
    print('start fn')
    threading.Timer(1, printer).start()
    print('stop fn')

if __name__ == '__main__':
    t=threading.Thread(target=fn, daemon=True)
    #t.daemon=True
    t.start()
    
    sys.exit()
