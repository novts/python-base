import threading
import time

def factorial(n):
    res = 1
    for i in range(1, n + 1):
        res *= i
    return res

start = time.time()

factorial(50000)
factorial(50000)

print("Execution time = {0:.5f}".format(time.time() - start))

start = time.time()

# creating thread 
t1 = threading.Thread(target=factorial, args=(50000,)) 
t2 = threading.Thread(target=factorial, args=(50000,)) 
  
# starting thread 1 
t1.start() 
# starting thread 2 
t2.start() 
  
# wait until thread 1 is completely executed 
t1.join() 
# wait until thread 2 is completely executed 
t2.join() 
  
# both threads completely executed 
print("Execution time = {0:.5f}".format(time.time() - start))
