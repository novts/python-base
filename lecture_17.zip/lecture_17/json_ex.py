import urllib.request, urllib.parse, urllib.error
import json

serviceurl = 'https://geocoder.api.here.com/6.2/geocode.json?app_id=fg79MR9FFAdbDV6V7Brc&app_code=lV_pIFdlTzoNSf8yL-K-Gg&'

while True:
    address = input('Enter location: ')
    if len(address) < 1: break

    url = serviceurl + urllib.parse.urlencode(
        {'searchtext': address})

    print('Retrieving', url)    
    uh = urllib.request.urlopen(url)
    data = uh.read().decode()
    print('Retrieved', len(data), 'characters')

    try:
        js = json.loads(data)
    except:
        js = None

    if not js:
     print('==== Failure To Retrieve ====')
     print(data)
     continue

    print(json.dumps(js, sort_keys=True, indent=4))

    lat = js["Response"]["View"][0]["Result"][0]["Location"]["DisplayPosition"]["Latitude"]
    lng = js["Response"]["View"][0]["Result"][0]["Location"]["DisplayPosition"]["Longitude"]
    print('lat', lat, 'lng', lng)
    location = js["Response"]["View"][0]["Result"][0]["Location"]["Address"]["Label"]
    print(location)
