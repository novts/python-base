from tkinter import *

root = Tk()

text = Text(root)
text.insert(END, "Hello, world!")
text.pack()

text.mark_set(INSERT, '1.5')
text.insert(INSERT, " and no Buy")
text.mark_set('here', '1.5')
text.insert('here', " and Buy")
text.mark_unset('here')

root.mainloop()