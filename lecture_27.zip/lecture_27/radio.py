from tkinter import *

master = Tk()

def callback():
    print ("var: ", var.get())


MODES = [
        ("Monochrome", "1"),
        ("Grayscale", "L"),
        ("True color", "RGB"),
        ("Color separation", "CMYK"),
    ]
var = StringVar()
var.set("L")
for text, mode in MODES:
    b = Radiobutton(master, text=text, variable=var, value=mode, command=callback, indicatoron=0)
    b.pack(anchor=W)


mainloop()
