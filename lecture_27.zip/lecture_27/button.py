from tkinter import *

master = Tk()

def callback():
    print ("click!")

b = Button(master, text="Buttons can display multiple lines of text (but only in one font)", command=callback, wraplength=80, anchor=W, justify=LEFT, padx=2, activebackground='red', bg='blue')
b.pack()
#b.config(relief=SUNKEN)

mainloop()