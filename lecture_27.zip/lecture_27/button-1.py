from tkinter import *

master = Tk()

def callback():
    print ("click!")

b=Button(master,text="Click", command=callback)
photo=PhotoImage(file="sam.gif")
b.config(image=photo, compound=TOP)
b.pack()

mainloop()