from tkinter import *

master = Tk()

w = Message(master, text="The widget can be used to display short text messages, using a single font")
w.pack()

mainloop()