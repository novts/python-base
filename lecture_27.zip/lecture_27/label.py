from tkinter import *

master = Tk()

w = Label(master, text="Hello, world!", underline=0, fg="red", font=("Helvetica", 16))
w.pack()

w = Label(master, text="Hello, world and Hello, world", wraplength=80)
w.pack()

v = StringVar()
Label(master, textvariable=v).pack()

v.set("New Text!")

mainloop()
