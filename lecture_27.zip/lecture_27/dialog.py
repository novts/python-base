from tkinter import *

from tkinter import messagebox

top = Tk()
top.geometry("100x100")

def mess():
    filename="text"
    try:
        fp = open(filename)
    except:
        messagebox.showwarning(
            "Open file",
            "Cannot open this file\n(%s)" % filename
        )
        return

B1 = Button(top, text = "Try", command = mess)
B1.place(x = 35,y = 50)

top.mainloop()