from tkinter import *

master = Tk()

def callback():
    print ("Entry: ", e.get())
    v.set("Print")


v = StringVar()
e = Entry(master, textvariable=v)
e.pack()

v.set("Entry")

B=Button(master, text="Submit", command=callback)
B.pack()

master.mainloop()
