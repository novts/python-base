from tkinter import *

master = Tk()

w = Scale(master, from_=0, to=10, resolution=0.1)
w.pack()

w1 = Scale(master, from_=0, to=200, orient=HORIZONTAL)
w1.pack()

def callback():
    print (w.get(), " ", w1.get())

b = Button(master, text="Get)", command=callback)
b.pack()

mainloop()