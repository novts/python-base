from tkinter import *

master = Tk()

var = StringVar(master)
var.set("one") # default value

w = OptionMenu(master, var, "one", "two", "three")
w.pack()

def ok():
    print ("value is", var.get())
    master.quit()

button = Button(master, text="OK", command=ok)
button.pack()

mainloop()