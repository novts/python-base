from tkinter import *

from tkinter import messagebox

top = Tk()
top.geometry("100x100")

def mess():
    if messagebox.askyesno("Print", "Print this report?"):
        print("Print this report")

B1 = Button(top, text = "Try", command = mess)
B1.place(x = 35,y = 50)

top.mainloop()