from tkinter import *

master = Tk()

def callback():
    print ("var: ", var.get())
    print ("var1: ", var1.get())

var = IntVar()

c = Checkbutton(master, text="Expand", variable=var, command=callback)
c.pack()

var1 = StringVar()
c1 = Checkbutton(master, text="Color image", variable=var1, onvalue="RGB", offvalue="L", command=callback)
c1.pack()


mainloop()
