from tkinter import *

master = Tk()

def CurSelet(event):
    widget = event.widget
    selection=widget.curselection()
    picked = widget.get(selection[0])
    print(picked) 
    print(listbox.get(ACTIVE))

listbox = Listbox(master, background="Blue", fg="white", selectbackground="Red", highlightcolor="Red")
listbox.pack()
listbox.bind('<<ListboxSelect>>',CurSelet)

listbox.insert(END, "a list entry")

for item in ["one", "two", "three", "four"]:
    listbox.insert(END, item)

b = Button(master, text="Delete", command=lambda listbox=listbox: listbox.delete(ACTIVE))
b.pack()

mainloop()