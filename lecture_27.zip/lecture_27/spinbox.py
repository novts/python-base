from tkinter import *

master = Tk()

w = Spinbox(master, from_=0, to=10)
w.pack()

w = Spinbox(values=(1, 2, 4, 8))
w.pack()

def callback():
    print (w.get())

b = Button(master, text="Get", command=callback)
b.pack()

mainloop()