from tkinter import *

master = Tk()

def callback():
    print ("Entry: ", e.get())
    e.delete(0,END)
    e.insert(0,"Print")


e=Entry(master, width=20)
e.insert(0,'Entry')
e.pack()

B=Button(master, text="Submit", command=callback)
B.pack()

master.mainloop()
