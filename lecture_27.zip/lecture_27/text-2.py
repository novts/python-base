from tkinter import *

def callback(event):
    info_window = Tk()
    info_window.overrideredirect(1)
    info_window.geometry("200x24+{0}+{1}".format(event.x_root-100, event.y_root-12))

    label = Label(info_window, text="Word definition goes here.")
    label.pack(fill=BOTH)

    info_window.bind_all("<Leave>", lambda e: info_window.destroy())  # Remove popup when pointer leaves the window
    info_window.mainloop()

root = Tk()

text = Text(root)
text.insert(END, "Hello, world!")
text.pack()

text.tag_add("tag", "1.7", "1.12")
text.tag_config("tag", foreground="blue")
text.tag_bind("tag", "<Button-1>", callback)

root.mainloop()