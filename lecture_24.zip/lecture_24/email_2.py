import smtplib, ssl

port = 1025  
smtp_server = "localhost"
sender_email = "my@gmail.com"
receiver_email = "your@gmail.com"

message = """\
Subject: Hi there

This message is sent from Python."""

with smtplib.SMTP(smtp_server, port) as server:
    server.sendmail(sender_email, receiver_email, message)
